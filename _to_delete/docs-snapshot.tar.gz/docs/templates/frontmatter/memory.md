---
# ── Core (required) ──────────────────────────────────────────────
type: memory
title: Retry logic must be idempotent for payment webhooks
slug: payment-webhook-idempotency-lesson
status: active            # draft | active | archived
owner: furkan@forgeos.dev
created: 2026-07-04

# ── Memory (required) ────────────────────────────────────────────
memory_type: lesson       # lesson | incident | retrospective | insight
source: project/payments-integration   # where this knowledge came from
                                       # (project/<slug>, workflow/<slug>, meeting, external)
captured_on: 2026-07-04

# ── Memory (optional) ────────────────────────────────────────────
confidence: high          # high | medium | low — how validated this knowledge is
expires: null             # ISO date if time-limited, else null
related:
  - standard/api-design
  - integration/stripe
tags:
  - payments
  - reliability
updated: 2026-07-04
---

# Retry logic must be idempotent for payment webhooks

<!-- Replace this body. Recommended sections: -->

## What happened

The concrete situation or observation, 2–4 sentences.

## What we learned

The reusable rule or insight, stated so someone with no context can apply it.

## What to do differently

The behavioral change — ideally linked to an updated standard, workflow or playbook.
