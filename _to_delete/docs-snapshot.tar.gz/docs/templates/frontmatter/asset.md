---
# ── Core (required) ──────────────────────────────────────────────
type: asset
title: ForgeOS Architecture Diagram
slug: forgeos-architecture-diagram
status: active            # draft | active | archived
owner: furkan@forgeos.dev
created: 2026-07-04

# ── Asset (required) ─────────────────────────────────────────────
asset_type: diagram       # image | diagram | logo | dataset | document | video
file: ./forgeos-architecture.svg    # path relative to docs/assets/
format: svg

# ── Asset (optional) ─────────────────────────────────────────────
source: draw.io           # where/how it was produced (tool, vendor, camera…)
source_file: ./forgeos-architecture.drawio   # editable original, if different
license: internal         # internal | cc-by | purchased | other
related:                  # documents that embed or depend on this asset
  - decision/adr-0001-mvp-architecture
tags:
  - architecture
updated: 2026-07-04
---

# ForgeOS Architecture Diagram

<!-- Replace this body. Recommended sections: -->

## Description

What the asset shows and when to use it.

## Update procedure

How to regenerate/re-export it when the source changes (keep the editable original next to the export).
