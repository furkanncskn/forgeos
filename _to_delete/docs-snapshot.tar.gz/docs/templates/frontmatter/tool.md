---
# ── Core (required) ──────────────────────────────────────────────
type: tool
title: GitHub
slug: github
status: active            # draft | active | archived
owner: furkan@forgeos.dev
created: 2026-07-04

# ── Tool (required) ──────────────────────────────────────────────
tool_type: saas           # saas | cli | library | internal | mcp-server
purpose: >
  Source control, pull requests and CI for all ForgeOS repositories.

# ── Tool (optional) ──────────────────────────────────────────────
url: https://github.com
license: commercial       # commercial | oss-mit | oss-apache2 | internal | other
cost: team plan, per-seat
used_by:                  # departments, agents or workflows that rely on it
  - engineering
  - agent/code-reviewer
  - workflow/pr-review
alternatives_considered:
  - GitLab
tags:
  - engineering
updated: 2026-07-04
---

# GitHub

<!-- Replace this body. Recommended sections: -->

## What we use it for

The specific capabilities we rely on (not everything the tool can do).

## Conventions

House rules for using this tool (naming, permissions, required settings) — link standards where they exist.

## Access

How a new person or agent gets access, and who approves it.
