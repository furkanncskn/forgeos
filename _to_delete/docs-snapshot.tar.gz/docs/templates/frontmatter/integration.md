---
# ── Core (required) ──────────────────────────────────────────────
type: integration
title: Stripe
slug: stripe
status: active            # draft | active | archived
owner: furkan@forgeos.dev
created: 2026-07-04

# ── Integration (required) ───────────────────────────────────────
system: Stripe            # external system name
vendor: Stripe, Inc.
integration_type: api     # api | webhook | mcp | file-exchange | database
auth_method: api-key      # api-key | oauth2 | basic | mtls | none
environments:
  - name: test
    base_url: https://api.stripe.com (test mode)
  - name: production
    base_url: https://api.stripe.com

# ── Integration (optional) ───────────────────────────────────────
data_exchanged:           # what flows in/out — feeds governance reviews
  - payment intents (outbound)
  - webhook events (inbound)
credentials_location: environment variables (never in docs)   # description only — NO secrets in /docs
depends_on_tools:
  - tool/stripe-cli
used_by:
  - project/payments-integration
  - workflow/payment-reconciliation
tags:
  - payments
updated: 2026-07-04
---

# Stripe

<!-- Replace this body. Recommended sections: -->

## Purpose

What this integration is for, in 1–2 sentences.

## Setup

How to configure it per environment (reference credential *names*, never values).

## Failure modes

Known failure modes, rate limits, and the escalation path when it breaks.
