---
# ── Core (required) ──────────────────────────────────────────────
type: standard
title: API Design Standard
slug: api-design
status: active            # draft | active | archived
owner: furkan@forgeos.dev
created: 2026-07-04

# ── Standard (required) ──────────────────────────────────────────
category: engineering     # engineering | process | security | data | communication | other
applies_to:               # who/what must follow it
  - apps/api
  - agent/code-reviewer
enforcement: required     # required | recommended

# ── Standard (optional) ──────────────────────────────────────────
review_cycle: quarterly   # how often the standard is revisited
supersedes: null          # standard/<slug> this replaces, if any
tags:
  - api
updated: 2026-07-04
---

# API Design Standard

<!-- Replace this body. Recommended sections: -->

## Rules

Numbered, testable rules. One sentence each. (e.g. "All endpoints are versioned under /api/v1.")

## Rationale

Why these rules exist, briefly.

## Exceptions

How to request an exception and who approves it (link: `decision/<slug>`).
