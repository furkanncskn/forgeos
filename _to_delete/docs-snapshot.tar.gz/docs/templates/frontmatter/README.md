# Frontmatter templates

Copy the template for your document type into the matching `/docs` folder, replace the example
values, and delete the placeholder comments. The Phase 1 ingestion pipeline (`@forgeos/markdown`)
validates every file in `/docs` against the Zod contract for its `type` — files that fail
validation are reported in the sync run and are not indexed.

## Core fields (required on every document type)

| Field | Rule |
| --- | --- |
| `type` | One of: `agent`, `prompt`, `workflow`, `standard`, `decision`, `memory`, `project`, `integration`, `tool`, `asset`. Must match the folder the file lives in. |
| `title` | Human-readable name, unique within its type. |
| `slug` | Kebab-case identifier, unique within its type. Used in URLs and cross-references. |
| `status` | Lifecycle state. Default vocabulary: `draft` \| `active` \| `archived` (the `decision` type uses its own vocabulary — see its template). |
| `owner` | Person or role accountable for the document (email or role slug). |
| `created` | ISO date (`YYYY-MM-DD`). |

`tags` (list) and `updated` (ISO date) are optional on all types but recommended.

## Cross-references

Reference other documents by `type/slug` (e.g. `agent/code-reviewer`, `standard/api-design`).
The sync pipeline resolves these into `document_links` rows, which power "used by" views in the UI.

## Templates in this folder

| Template | Target folder |
| --- | --- |
| `agent.md` | `docs/agents/` |
| `prompt.md` | `docs/prompts/` |
| `workflow.md` | `docs/workflows/` |
| `standard.md` | `docs/standards/` |
| `decision.md` | `docs/decisions/` |
| `memory.md` | `docs/memory/` |
| `project.md` | `docs/projects/` |
| `integration.md` | `docs/integrations/` |
| `tool.md` | `docs/tools/` |
| `asset.md` | `docs/assets/` |
