---
# ── Core (required) ──────────────────────────────────────────────
type: prompt
title: Code Review Checklist
slug: code-review-checklist
status: active            # draft | active | archived
owner: furkan@forgeos.dev
created: 2026-07-04

# ── Prompt (required) ────────────────────────────────────────────
use_case: >
  Instructs an agent to review a pull request diff against ForgeOS
  standards and produce a structured verdict.
variables:                # every {{placeholder}} used in the body
  - name: diff
    description: Unified diff of the pull request
    required: true
    example: "diff --git a/src/index.ts ..."
  - name: standards
    description: Relevant standard excerpts to enforce
    required: false
    example: "API responses must use the shared error envelope."

# ── Prompt (optional) ────────────────────────────────────────────
agent: agent/code-reviewer   # owning agent, if any
version_label: v1
tags:
  - engineering
updated: 2026-07-04
---

# Code Review Checklist

<!-- The prompt text itself lives in the body. Use {{variable}} placeholders
     declared in `variables` above — the Prompt Library's render endpoint
     substitutes them. -->

Review the following diff against our standards.

Diff:

```
{{diff}}
```

Standards to enforce: {{standards}}

Return a verdict (`approve` or `request-changes`) and a list of findings.
