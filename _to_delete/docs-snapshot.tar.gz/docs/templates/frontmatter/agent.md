---
# ── Core (required) ──────────────────────────────────────────────
type: agent
title: Code Reviewer
slug: code-reviewer
status: active            # draft | active | archived
owner: furkan@forgeos.dev
created: 2026-07-04

# ── Agent (required) ─────────────────────────────────────────────
purpose: >
  Reviews pull requests against ForgeOS coding standards and flags
  correctness, security and maintainability issues.
department: engineering   # slug of a docs/departments entry
model: claude-sonnet      # suggested model tier
capabilities:
  - code-review
  - security-analysis

# ── Agent (optional) ─────────────────────────────────────────────
prompts:                  # prompt slugs this agent uses
  - prompt/code-review-checklist
workflows:                # workflows this agent participates in
  - workflow/pr-review
input_schema:             # free-form JSON-ish description of expected input
  pull_request_url: string
  diff: string
output_schema:
  verdict: approve | request-changes
  findings: list
escalates_to: human       # human | agent/<slug> | none
tags:
  - engineering
  - quality
updated: 2026-07-04
---

# Code Reviewer

<!-- Replace this body. Recommended sections: -->

## Role

What this agent does and does not do, in 2–3 sentences.

## Operating rules

Constraints, standards it must enforce (link them: `standard/<slug>`), and when it must escalate.

## Examples

One short input → output example.
