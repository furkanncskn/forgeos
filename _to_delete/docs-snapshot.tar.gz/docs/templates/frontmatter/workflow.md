---
# ── Core (required) ──────────────────────────────────────────────
type: workflow
title: Pull Request Review
slug: pr-review
status: active            # draft | active | archived
owner: furkan@forgeos.dev
created: 2026-07-04

# ── Workflow (required) ──────────────────────────────────────────
trigger: A pull request is opened or updated
steps:
  - id: triage
    name: Triage the PR
    step_type: agent      # agent | human | decision | tool
    agent: agent/code-reviewer
    prompt: prompt/code-review-checklist
    next: [verdict]
  - id: verdict
    name: Approve or request changes
    step_type: decision
    next: [merge, notify-author]
  - id: merge
    name: Merge
    step_type: tool
    tool: tool/github
    next: []
  - id: notify-author
    name: Notify author
    step_type: human
    next: []

# ── Workflow (optional) ──────────────────────────────────────────
inputs:
  - pull_request_url
outputs:
  - review verdict
  - merge status
standards:                # standards this workflow enforces
  - standard/api-design
diagram: |                # optional mermaid; rendered by the Workflow Viewer
  flowchart LR
    triage --> verdict
    verdict -->|approve| merge
    verdict -->|changes| notify-author
tags:
  - engineering
updated: 2026-07-04
---

# Pull Request Review

<!-- Replace this body. Recommended sections: -->

## Purpose

Why this workflow exists and what outcome it guarantees.

## Steps in detail

One short paragraph per step: entry criteria, who/what executes it, exit criteria.

## Failure handling

What happens when a step fails or times out.
