---
# ── Core (required) ──────────────────────────────────────────────
type: project
title: Payments Integration
slug: payments-integration
status: active            # draft | active | archived
owner: furkan@forgeos.dev
created: 2026-07-04

# ── Project (required) ───────────────────────────────────────────
project_status: in-progress   # planning | in-progress | paused | done | cancelled
lead: furkan@forgeos.dev
departments:
  - engineering
  - finance
start_date: 2026-07-01
objectives:
  - Accept card payments via Stripe in the EU region
  - Reconcile payouts automatically into the finance workflow

# ── Project (optional) ───────────────────────────────────────────
end_date: null            # ISO date when known
sponsor: ceo              # role slug or email
workflows:                # workflows created or used by this project
  - workflow/payment-reconciliation
decisions:                # key decisions made in this project
  - decision/adr-0002-postgres-fts
tags:
  - payments
updated: 2026-07-04
---

# Payments Integration

<!-- Replace this body. Recommended sections: -->

## Goal

The outcome this project delivers and how we will know it is done.

## Scope

In scope / out of scope, as two short lists.

## Status log

Dated one-line updates, newest first (e.g. `2026-07-04 — kickoff, scope agreed`).
