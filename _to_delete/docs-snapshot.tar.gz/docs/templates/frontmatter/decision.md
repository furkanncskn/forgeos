---
# ── Core (required) ──────────────────────────────────────────────
type: decision
title: Use PostgreSQL full-text search for the MVP
slug: adr-0002-postgres-fts
status: accepted          # proposed | accepted | rejected | deprecated | superseded
owner: furkan@forgeos.dev
created: 2026-07-04

# ── Decision (required) ──────────────────────────────────────────
decision_id: ADR-0002     # unique, sequential
deciders:
  - furkan@forgeos.dev
decided_on: 2026-07-04

# ── Decision (optional) ──────────────────────────────────────────
supersedes: null          # decision/<slug> this replaces
related:
  - decision/adr-0001-mvp-architecture
  - standard/api-design
tags:
  - architecture
updated: 2026-07-04
---

# ADR-0002 — Use PostgreSQL full-text search for the MVP

<!-- Replace this body. Standard ADR sections: -->

## Context

What situation forced a decision.

## Decision

What was decided, in one or two sentences.

## Consequences

What becomes easier, what becomes harder, and what we accept as a trade-off.

## Alternatives considered

The options that were rejected and the one-line reason each was rejected.
